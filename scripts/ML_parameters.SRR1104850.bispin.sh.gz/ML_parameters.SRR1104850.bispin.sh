#!/bin/sh
/scratch/jsporter/AlignmentML/do_ML.sh SRR1104850 bispin
