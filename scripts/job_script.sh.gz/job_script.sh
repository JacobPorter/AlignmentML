#!/bin/bash

srun -A ndssl -t 72:00:00  --exclusive  ./ML_parameters.sh 
