#!/bin/sh
/scratch/jsporter/AlignmentML/do_ML.sh SRR1534392 bispin
