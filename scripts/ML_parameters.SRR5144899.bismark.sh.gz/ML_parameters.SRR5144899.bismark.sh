#!/bin/sh
/scratch/jsporter/AlignmentML/do_ML.sh SRR5144899 bismark
