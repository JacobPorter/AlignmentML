#!/bin/sh
/scratch/jsporter/AlignmentML/do_ML.sh ERR699568 bfast-gap
